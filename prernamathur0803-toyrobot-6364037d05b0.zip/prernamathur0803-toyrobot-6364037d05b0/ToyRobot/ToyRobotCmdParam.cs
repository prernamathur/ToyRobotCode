﻿using System;
using static ToyRobot.CommandsMove;

namespace ToyRobot
{
    public class ToyRobotCmdParam
    {
        public CommandsMove Position { get; set; }
        public Direction Direction { get; set; }

        public ToyRobotCmdParam(CommandsMove position, Direction direction)
        {
            Position = position;
            Direction = direction;
        }
    }
}
